Please use any monospaced fonts for better readability. It always advised to disable Word Wrap
 _________________
|                 |
|  Installation.  |
|_________________|

Copy and paste all the contents "GTA San Andreas" folder to your game directory/folder

Then copy and paste the desired preset you want (remember there are tons of preset on RenderHook Discord server. Server Invite link - https://discord.com/invite/VX7zZ56)

_______________________________________________________________________________________

   _____              _ _ _       
  / ____|            | (_) |      
 | |     _ __ ___  __| |_| |_ ___ 
 | |    | '__/ _ \/ _` | | __/ __|
 | |____| | |  __/ (_| | | |_\__ \
  \_____|_|  \___|\__,_|_|\__|___/
                                  
                                  
Credits-:

ASILoader        - Silent
SilentPatchSA    - Silent
Cleo+            - JuniorDjjr
RenderHook Fixes - JuniorDjjr
Widescreen Fix   - ThirteenAG

_______________________________________________________________________________________


   _____            _             _       
  / ____|          | |           | |      
 | |     ___  _ __ | |_ ___ _ __ | |_ ___ 
 | |    / _ \| '_ \| __/ _ \ '_ \| __/ __|
 | |___| (_) | | | | ||  __/ | | | |_\__ \
  \_____\___/|_| |_|\__\___|_| |_|\__|___/
                                          
                                          
Contents-:

EXE 1.0 US Hoodlum + 4 GB largeaddress patch
Silent's ASI Loader
CLEO v4.4.0 - No dev files
CLEO+ v1.1.0
ModLoader v0.3.7
SilentPatch v1.1 
Widescreen Fix by ThirteenAG - May 17, 2020

_______________________________________________________________________________________
