  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "RenderHookFix" to your ModLoader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


Currently only for RenderHook 2020 (SA) version: https://www.mixmods.com.br/2018/03/renderhook-by-petkagta.html

Avoid renaming .asi files.
If RenderHook ins't installed, will not activate.

You can include this fix in the preset download, as long as you credit me.
It is possible that there are still new versions with more fixes, so it is recommended to include the post link:
https://www.mixmods.com.br/2021/10/renderhook-fix-correcoes-para-o-rh.html


Version: v1.0
--------------------

Author: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
